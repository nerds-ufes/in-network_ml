#!/bin/bash

if [ "$1" == "" ]; then
	echo "Sintax:"
	#echo "$0 [iface] [dest_ip] [dest_mac] [rate (in Mb/s)] [pkt_size] [time_to_run (in secs, default: 60s)]"
	echo "$0 [iface] [dest_ip] [dest_mac] [rate (in Mb/s)] [pkt_size] [count]"
	exit 0
fi

modprobe pktgen

# CPU to use
CPU=0
iface=$1
ip=$2
mac=$3
rate=$4
pktsize=$5
#timetorun=$6
count=$6

PGTX="/proc/net/pktgen/${iface}"

#if [ "$timetorun" == "" ]; then
#	timetorun=60
#fi

#count=$((rate * 1000000 / 8 / pktsize * timetorun))
# set infinite
#count=0

#mac=$(arping -I ${iface} ${ip} -c1 | grep Unicast | cut -d \[ -f 2 | cut -d \] -f 1)
if [ "$mac" == "" ]; then
	echo "Error obtaining mac address of destination: ${ip}"
	exit 1
fi

pgset()
{
    local result

    echo $1 > $PGDEV

    result=`cat $PGDEV | fgrep "Result: OK:"`
    if [ "$result" = "" ]; then
         cat $PGDEV | fgrep Result:
    fi
}

pg()
{
    echo inject > $PGDEV
    cat $PGDEV
}

## Start the configuration

# Thread configure: for each cpu
for PGDEV in /proc/net/pktgen/kpktgend_*; do
	state=$(grep rem_device_all ${PGDEV})
	if [ "${state}" == "" ]; then
		echo "Removing device on ${PGDEV}"
		pgset "rem_device_all"
	fi
done
PGDEV="/proc/net/pktgen/kpktgend_${CPU}"
echo "Adding device ${iface}"
pgset "add_device ${iface}" 


PGDEV=$PGTX
### DEBUG
echo "Configuring $PGDEV:"
echo "count=${count}"
echo "pkt_size=${pktsize}"
echo "rate=${rate}"
echo "dst_ipc=${ip}"
echo "dst_mac=${mac}"

# infinite
pgset "count ${count}"
# test SO
#pgset "clone_skb 1"
# test driver
#pgset "clone_skb 100000"
pgset "clone_skb 0"
pgset "pkt_size ${pktsize}"
#pgset "ratep ${ratep}"
pgset "rate ${rate}M"
pgset "udp_dst_min 5000"
pgset "udp_dst_max 5000"
#pgset "queue_map_min 0"
#pgset "queue_map_max 4"
#pgset "delay 96"
pgset "dst ${ip}" #IP do destino
pgset "dst_mac ${mac}" #MAC da interface


PGDEV="/proc/net/pktgen/pgctrl"

echo "Running... ctrl-C to stop"
#sleep ${timetorun} && pgset "stop" &
pgset "start"
echo "Done"

# Result can be vieved in /proc/net/pktgen/eth1
