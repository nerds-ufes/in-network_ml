
import subprocess
import sys, os
import time

#rate = [1, 1024, 10240]
#size = [64, 96, 128, 256, 512, 1024, 1400]
#hops = [1, 2 ,3 , 4, 5, 6, 7, 8, 9]

rate = [1, 1024]
size = [96, 1400]
hops = [ 6, 7, 8, 9]


print('######## RUNNING EXPERIMENTS ########')

print(' - REMOVING OLD RESULTS')


directory = "./results"

files_in_directory = os.listdir(directory)
filtered_files = [file for file in files_in_directory if file.endswith(".txt")]
for file in filtered_files:
	path_to_file = os.path.join(directory, file)
	os.remove(path_to_file)

for rt in rate:
    for sz in size:
        for hp in hops:
            print('- deploy again...')
            #print(subprocess.Popen("./exec.sh", shell=True, stdout=subprocess.PIPE).stdout.read())
            print('- config')
            print(f'- rate: {rt} size: {sz} hops:{hp}')

            subprocess.Popen("tcpdump -B 65535 -i vf0_1 -w teste.pcap", shell=True, stdout=subprocess.PIPE)
            print('  - sending packets')
            if rt == 1:
                print(subprocess.Popen(f"python3 send.py vf0_0 10.0.100.{hp} {sz} ", shell=True, stdout=subprocess.PIPE).stdout.read())
            else:
                print(subprocess.Popen(f"./pktgen.sh vf0_0 10.0.100.{hp} 00:15:4d:00:00:01 {rt} {sz} 1000 ", shell=True, stdout=subprocess.PIPE).stdout.read())
            print('  - waiting 3 sec')
            time.sleep(3)
            print( subprocess.Popen(f"killall tcpdump", shell=True, stdout=subprocess.PIPE).stdout.read())
            print( subprocess.Popen(f"python3 processPcap.py results/exp_rate{rt}_size{sz}_hop{hp}.txt ", shell=True, stdout=subprocess.PIPE).stdout.read())
