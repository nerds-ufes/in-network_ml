#!/usr/bin/env python
import sys
import socket

from scapy.all import sendp, sendpfast, get_if_list, get_if_hwaddr, bind_layers
from scapy.all import Packet
from scapy.all import Ether, IP, UDP, Raw
from scapy.fields import *
import readline
from scapy.all import  IPOption
from scapy.layers.inet import _IPOption_HDR

import time

def main():

    addr = socket.gethostbyname(sys.argv[2])
    iface = sys.argv[1]

    for x in range(60):
        pkt = Ether(src="00:15:4d:00:00:00", dst="ff:ff:ff:ff:ff:ff")
        #try:
            # pkt = pkt / SourceRoute(nrouteid=int(p))
            #pkt = pkt / SourceRoute(nrouteid=option)
        #except ValueError:
        #    print('ERROR: SourceRoute')

        pkt = pkt / IP(src="10.0.1.1",dst=addr) /  Raw('X'*int(sys.argv[3]))
        pkt.show2()

        #sendpfast([pkt], pps=1, loop=100, iface=iface)

        sendp(pkt, iface=iface, verbose=False)

        time.sleep(1)

if __name__ == "__main__":
    main()