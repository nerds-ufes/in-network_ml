#!/usr/bin/env python
import sys
import struct

from scapy.all import sniff, sendp, hexdump, get_if_list, get_if_hwaddr, PcapReader
from scapy.all import Packet, IPOption
from scapy.all import PacketListField, ShortField, IntField, LongField, BitField, FieldListField, FieldLenField
from scapy.all import IP, UDP, Raw
from scapy.layers.inet import _IPOption_HDR
import binascii

from scapy.config import Conf
Conf.bufsize = 655350000

class SourceRoute(Packet):
    # fields_desc = [ BitField("bos", 0, 1),
    #                 BitField("port", 0, 15)]
    fields_desc = [BitField("nrouteid", 0, 144)]

class IPOption_INT(IPOption):
    name = "INT"
    option = 31
    fields_desc = [ _IPOption_HDR,
                    FieldLenField("length", None, fmt="B",
                                  length_of="int_headers",
                                  adjust=lambda pkt,l:l*2),
                    ShortField("count", 0),
                    BitField("ini", 0, 64),
                    BitField("fim", 0, 64)]


def handle_pkt(pkt):

    ini = 0
    fim = 0
    l = 0 
    
    #pkt.show2()
    # pkt[Timemeter].show2()
    
    for p in pkt[IP]:
        l = p.len
        fim = p['INT'].fim
        ini = p['INT'].ini

    print ('%d'%(fim-ini))    
    
    #pkt.show2()
    #hexdump(pkt)
    sys.stdout.flush()


def main():
    scapy_cap = PcapReader('teste.pcap')
    for p in scapy_cap:
        handle_pkt(p)

if __name__ == '__main__':
    sys.stdout = open(sys.argv[1], 'w')

    main()
