#!/bin/bash

if [ $# -gt 0 ]; then
    if [ "$1" == "b" ]; then
        make clean

        #nfp4build --nfp4c_p4_version 16 --no-debug-info --nfirc_mac_ingress_timestamp -e -p out -o firmware.nffw -l lithium -4 $1
        #nfp4build --nfp4c_p4_version 16 --no-debug-info  -e -p out -o firmware.nffw -l lithium -4 $1

        make
    fi        
fi
if [ $? -eq 0 ]; then
    echo Compiler OK
    rtecli design-load -f firmware.nffw -p out/pif_design.json
    echo Load firmware OK	
    rtecli config-reload -c edge_rules.json
    echo reload config rules OK
    #ip netns exec ns1 ping 192.168.255.40
    
    #tcpdump -i vf0_1

    #python3 send.py 10.0.0.1 hello 1


else
    echo FAIL
fi    
